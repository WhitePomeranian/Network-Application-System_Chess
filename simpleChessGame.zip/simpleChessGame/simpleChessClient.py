import pygame
import threading
import xmlrpc.client
from datetime import datetime

PORT = 8888

class ChessThread(threading.Thread):
    
    def __init__(self, username, color, server):
        super().__init__()
        self.playerName = username
        self.chessColor = color
        self.server = server
        self.start()
    #end of __init__
    
    def drawBoard(self):
        
        for i in range (32):
            column = i % 4
            row = i // 4
            if row % 2 == 0:
                pygame.draw.rect(self.gameScreen, "light gray", [600 - (column * 200), row * 100, 100, 100])
            else:
                pygame.draw.rect(self.gameScreen, "light gray", [700 - (column * 200), row * 100, 100, 100])
                
            pygame.draw.rect(self.gameScreen, "gray", [0, 800, 1000, 100])
            pygame.draw.rect(self.gameScreen, "gold", [0, 800, 1000, 100], 5)
            pygame.draw.rect(self.gameScreen, "gold", [800, 0, 200, 900], 5)
            statusText = [f"White: Select a piece to move! {self.showTimer}", f"White: Select a destination! {self.showTimer}", "Waiting player to move!", f"Black: Select a piece to move! {self.showTimer}", f"Black: Select a destination! {self.showTimer}"]
            self.gameScreen.blit(self.mediumFont.render(statusText[self.turnStep], True, "black"), (20, 835))
            
            for i in range (9):
                pygame.draw.line(self.gameScreen, "black", (0, 100 * i), (800, 100 * i), 2)
                pygame.draw.line(self.gameScreen, "black", (100 * i, 0), (100 * i, 800), 2)
                
            self.gameScreen.blit(self.mediumFont.render("Surrender", True, "black"), (813, 833))
    #end of drawBoard
    
    def drawPieces(self):
        
        for i in range (len(self.whitePieces)):
            index = self.pieceList.index(self.whitePieces[i])
            self.gameScreen.blit(self.whiteImages[index], (self.whiteLocations[i][0] * 100 + 10, self.whiteLocations[i][1] * 100 + 10))
            
            if self.turnStep < 2:
                if self.selection == i:
                    pygame.draw.rect(self.gameScreen, "red", [self.whiteLocations[i][0] * 100 + 1, self.whiteLocations[i][1] * 100 + 1, 100, 100], 2)
                
        for i in range (len(self.blackPieces)):
            index = self.pieceList.index(self.blackPieces[i])
            self.gameScreen.blit(self.blackImages[index], (self.blackLocations[i][0] * 100 + 10, self.blackLocations[i][1] * 100 + 10))
            
            if self.turnStep >= 2:
                if self.selection == i:
                    pygame.draw.rect(self.gameScreen, "blue", [self.blackLocations[i][0] * 100 + 1, self.blackLocations[i][1] * 100 + 1, 100, 100], 2)
    #end of drawPieces
    
    def checkOptions(self, pieces, locations, turn):
        moveList = []
        allMoveList = []
        
        for i in range(len(pieces)):
            location = locations[i]
            piece = pieces[i]
            
            match piece:
                case "pawn":
                    moveList = self.checkPawnMoves(location, turn)
                case "rook":
                    moveList = self.checkRookMoves(location, turn)
                case "knight":
                    moveList = self.checkKnightMoves(location, turn)
                case "bishop":
                    moveList = self.checkBishopMoves(location, turn)
                case "king":
                    moveList = self.checkKingMoves(location, turn)
                case _:
                    moveList = self.checkQueenMoves(location, turn)
            
            allMoveList.append(moveList)
            
        return allMoveList
    #end of checkOptions
    
    def checkPawnMoves(self, position, color):
        moveList = []
        
        if self.chessColor == "black":
            if color == "white":
                if (position[0], position[1] + 1) not in self.whiteLocations and (position[0], position[1] + 1) not in self.blackLocations and position[1] < 7:
                    moveList.append((position[0], position[1] + 1))
                if (position[0], position[1] + 2) not in self.whiteLocations and (position[0], position[1] + 2) not in self.blackLocations and \
                    (position[0], position[1] + 1) not in self.whiteLocations and (position[0], position[1] + 1) not in self.blackLocations and position[1] == 1:
                    moveList.append((position[0], position[1] + 2))
                if (position[0] + 1, position[1] + 1) in self.blackLocations:
                    moveList.append((position[0] + 1, position[1] + 1))
                if (position[0] - 1, position[1] + 1) in self.blackLocations:
                    moveList.append((position[0] - 1, position[1] + 1))
            else:
                if (position[0], position[1] - 1) not in self.whiteLocations and (position[0], position[1] - 1) not in self.blackLocations and position[1] > 0:
                    moveList.append((position[0], position[1] - 1))
                if (position[0], position[1] - 2) not in self.whiteLocations and (position[0], position[1] - 2) not in self.blackLocations and \
                    (position[0], position[1] - 1) not in self.whiteLocations and (position[0], position[1] - 1) not in self.blackLocations and position[1] == 6:
                    moveList.append((position[0], position[1] - 2))
                if (position[0] + 1, position[1] - 1) in self.whiteLocations:
                    moveList.append((position[0] + 1, position[1] - 1))
                if (position[0] - 1, position[1] - 1) in self.whiteLocations:
                    moveList.append((position[0] - 1, position[1] - 1))
        else:
            if color == "black":
                if (position[0], position[1] + 1) not in self.whiteLocations and (position[0], position[1] + 1) not in self.blackLocations and position[1] < 7:
                    moveList.append((position[0], position[1] + 1))
                if (position[0], position[1] + 2) not in self.whiteLocations and (position[0], position[1] + 2) not in self.blackLocations and \
                    (position[0], position[1] + 1) not in self.whiteLocations and (position[0], position[1] + 1) not in self.blackLocations and position[1] == 1:
                    moveList.append((position[0], position[1] + 2))
                if (position[0] + 1, position[1] + 1) in self.whiteLocations:
                    moveList.append((position[0] + 1, position[1] + 1))
                if (position[0] - 1, position[1] + 1) in self.whiteLocations:
                    moveList.append((position[0] - 1, position[1] + 1))
            else:
                if (position[0], position[1] - 1) not in self.whiteLocations and (position[0], position[1] - 1) not in self.blackLocations and position[1] > 0:
                    moveList.append((position[0], position[1] - 1))
                if (position[0], position[1] - 2) not in self.whiteLocations and (position[0], position[1] - 2) not in self.blackLocations and \
                    (position[0], position[1] - 1) not in self.whiteLocations and (position[0], position[1] - 1) not in self.blackLocations and position[1] == 6:
                    moveList.append((position[0], position[1] - 2))
                if (position[0] + 1, position[1] - 1) in self.blackLocations:
                    moveList.append((position[0] + 1, position[1] - 1))
                if (position[0] - 1, position[1] - 1) in self.blackLocations:
                    moveList.append((position[0] - 1, position[1] - 1))
                
        return moveList
    #end of checkPawnMoves
    
    def checkRookMoves(self, position, color):
        moveList = []
        
        if color == "white":
            enemyList = self.blackLocations
            friendList = self.whiteLocations
        else:
            enemyList = self.whiteLocations
            friendList = self.blackLocations
            
        for i in range (4):
            path = True
            chain = 1
            
            match i:
                case 0:
                    x = 0
                    y = 1
                case 1:
                    x = 0
                    y = -1
                case 2:
                    x = 1
                    y = 0
                case _:
                    x = -1
                    y = 0
                
            while path:
                
                if (position[0] + (chain * x), position[1] + (chain * y)) not in friendList and \
                    0 <= position[0] + (chain * x) <= 7 and 0 <= position[1] + (chain * y) <= 7:
                    moveList.append((position[0] + (chain * x), position[1] + (chain * y)))
                    
                    if (position[0] + (chain * x), position[1] + (chain * y)) in enemyList:
                        path = False
                        
                    chain += 1
                else:
                    path = False
                
        return moveList
    #end of checkRookMoves
    
    def checkKnightMoves(self, position, color):
        moveList = []
        
        if color == "white":
            friendList = self.whiteLocations
        else:
            friendList = self.blackLocations
            
        targets = [(1, 2), (1, -2), (2, 1), (2, -1), (-1, 2), (-1, -2), (-2, 1), (-2, -1)]
        
        for i in range (8):
            target = (position[0] + targets[i][0], position[1] + targets[i][1])
            
            if target not in friendList and 0 <= target[0] <= 7 and 0 <= target[1] <= 7:
                moveList.append(target)
                
        return moveList
    #end of checkKnightMoves
    
    def checkBishopMoves(self, position, color):
        moveList = []
        
        if color == "white":
            enemyList = self.blackLocations
            friendList = self.whiteLocations
        else:
            enemyList = self.whiteLocations
            friendList = self.blackLocations
            
        for i in range (4):
            path = True
            chain = 1
            
            match i:
                case 0:
                    x = 1
                    y = -1
                case 1:
                    x = -1
                    y = -1
                case 2:
                    x = 1
                    y = 1
                case _:
                    x = -1
                    y = 1
                
            while path:
                
                if (position[0] + (chain * x), position[1] + (chain * y)) not in friendList and \
                    0 <= position[0] + (chain * x) <= 7 and 0 <= position[1] + (chain * y) <= 7:
                    moveList.append((position[0] + (chain * x), position[1] + (chain * y)))
                    
                    if (position[0] + (chain * x), position[1] + (chain * y)) in enemyList:
                        path = False
                        
                    chain += 1
                else:
                    path = False
        
        return moveList
    #end of checkBishopMoves
    
    def checkKingMoves(self, position, color):
        moveList = []
        
        if color == "white":
            friendList = self.whiteLocations
        else:
            friendList = self.blackLocations
            
        targets = [(1, 0), (1, 1), (1, -1), (-1, 0), (-1, 1), (-1, -1), (0, 1), (0, -1)]
        
        for i in range (8):
            target = (position[0] + targets[i][0], position[1] + targets[i][1])
            
            if target not in friendList and 0 <= target[0] <= 7 and 0 <= target[1] <= 7:
                moveList.append(target)
        
        return moveList
    #end of checkKingMoves
    
    def checkQueenMoves(self, position, color):
        moveList = self.checkBishopMoves(position, color)
        secondList = self.checkRookMoves(position, color)
        
        for i in range (len(secondList)):
            moveList.append(secondList[i])
        
        return moveList
    #end of checkQueenMoves
    
    def checkValidMoves(self):
        
        if self.turnStep < 2:
            optionsList = self.whiteOptions
        else:
            optionsList = self.blackOptions
        
        validOptions = optionsList[self.selection]
        
        return validOptions
    #end of checkValidMoves
    
    def drawValid(self, moves):
        
        if self.turnStep < 2:
            color = "red"
        else:
            color = "blue"
        
        for i in range (len(moves)):
            pygame.draw.circle(self.gameScreen, color, (moves[i][0] * 100 + 50, moves[i][1] * 100 + 50), 5)
    #end of drawValid
    
    def drawCaptured(self):
        
        for i in range (len(self.capturedPiecesWhite)):
            capturedPiece = self.capturedPiecesWhite[i]
            index = self.pieceList.index(capturedPiece)
            self.gameScreen.blit(self.blackImagesSmall[index], (825, 5 + 50 * i))
            
        for i in range (len(self.capturedPiecesBlack)):
            capturedPiece = self.capturedPiecesBlack[i]
            index = self.pieceList.index(capturedPiece)
            self.gameScreen.blit(self.whiteImagesSmall[index], (925, 5 + 50 * i))
    #end of drawCaptured
    
    def drawCheck(self):
        
        if "king" in self.whitePieces:
            kingIndex = self.whitePieces.index("king")
            kingLocation = self.whiteLocations[kingIndex]
            
            for i in range (len(self.blackOptions)):
                if kingLocation in self.blackOptions[i]:
                    if self.counter < 15:
                        pygame.draw.rect(self.gameScreen, "dark red", [self.whiteLocations[kingIndex][0] * 100 + 1, self.whiteLocations[kingIndex][1] * 100 + 1, 100, 100], 5)

        if "king" in self.blackPieces:
            kingIndex = self.blackPieces.index("king")
            kingLocation = self.blackLocations[kingIndex]
                
            for i in range (len(self.whiteOptions)):
                if kingLocation in self.whiteOptions[i]:
                    if self.counter < 15:
                        pygame.draw.rect(self.gameScreen, "dark blue", [self.blackLocations[kingIndex][0] * 100 + 1, self.blackLocations[kingIndex][1] * 100 + 1, 100, 100], 5)
    #end of drawCheck
    
    def drawGameOver(self):
        pygame.draw.rect(self.gameScreen, "black", [200, 200, 550, 70])
        
        if self.winner == "white":
            match self.winStatus:
                case 1:
                    self.gameScreen.blit(self.font.render('BLACK king has been captured, WHITE won the game!', True, "white"), (210, 210))
                case 2:
                    self.gameScreen.blit(self.font.render('BLACK ran out of time, WHITE won the game!', True, "white"), (210, 210))
                case 3:
                    self.gameScreen.blit(self.font.render('BLACK surrendered, WHITE won the game!', True, "white"), (210, 210))
                case 4:
                    self.gameScreen.blit(self.font.render('BLACK has quit the game, WHITE won the game!', True, "white"), (210, 210))
        elif self.winner == "black":
            match self.winStatus:
                case 1:
                    self.gameScreen.blit(self.font.render('WHITE king has been captured, BLACK won the game!', True, "white"), (210, 210))
                case 2:
                    self.gameScreen.blit(self.font.render('WHITE ran out of time, BLACK won the game!', True, "white"), (210, 210))
                case 3:
                    self.gameScreen.blit(self.font.render('WHITE surrendered, BLACK won the game!', True, "white"), (210, 210))
                case 4:
                    self.gameScreen.blit(self.font.render('WHITE has quit the game, BLACK won the game!', True, "white"), (210, 210))
        else:
            self.gameScreen.blit(self.font.render('30 turn passed and no chess captured, GAME DRAW!', True, "white"), (210, 210))
        self.gameScreen.blit(self.font.render("Press enter to quit!", True, "white"), (210, 240))
    #end of drawGameOver
    
    def run(self):
        pygame.init()
        self.gameScreen = pygame.display.set_mode([1000,900])
        pygame.display.set_caption("網路程式設計專題")
        self.pygameIcon = pygame.image.load("assets/images/black_queen.png")
        pygame.display.set_icon(self.pygameIcon)
        self.font = pygame.font.Font("freesansbold.ttf", 20)
        self.bigFont = pygame.font.Font("freesansbold.ttf", 50)
        self.mediumFont = pygame.font.Font("freesansbold.ttf", 35)
        self.timer = pygame.time.Clock()
        self.counter = 0     #國王即將被吃的時候格子會閃爍，該參數控制格子閃爍的時機
        self.fps = 60
        self.winner = ""     #記錄贏家顔色
        self.winStatus = 0     #記錄游戲結束的原因
        self.userSetTime = 180     #房主設定的總限制時間
        self.awardTime = 5     #房主設定的獎勵時間
        self.leftTime = self.userSetTime     #玩家思考的剩餘時間
        self.showTimer = -1     #顯示在熒幕上的剩餘時間
        self.recordWhiteSec = -1     #記錄白方回合轉變那一瞬間的當前時間
        self.recordBlackSec = -1     #記錄黑方回合轉變那一瞬間的當前時間
        self.gameOver = False     #True代表游戲結束
        
        self.whitePieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]     #白方所有棋子
        self.blackPieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]     #黑方所有棋子
        
        if self.chessColor == "black":
            self.whiteLocations = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]     #白方棋子位置，與whitePieces的index聯動
            self.blackLocations = [(0, 7), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (7, 6)]     #黑方棋子位置，與blackPieces的index聯動
        else:
            self.whiteLocations = [(0, 7), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (7, 6)]     #白方棋子位置，與whitePieces的index聯動
            self.blackLocations = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]     #黑方棋子位置，與blackPieces的index聯動
        self.capturedPiecesWhite = []     #捕獲到的白棋子
        self.capturedPiecesBlack = []     #捕獲到的黑棋子
        self.turnStep = 2     #整個程式運作的核心，該參數控制大部分運行，turnStep=2代表等待對方移動
        self.selection = 100    #記錄玩家選擇的棋子的index
        self.validMoves = []     #合法的移動路徑
        self.returnCheck = "not your turn"     #server回傳的參數，查看當前回合是否到你移動棋子
        
        self.whiteQueen = pygame.transform.scale(pygame.image.load("assets/images/white_queen.png"), (80, 80))
        self.whiteQueenSmall = pygame.transform.scale(self.whiteQueen, (45, 45))
        self.whiteKing = pygame.transform.scale(pygame.image.load("assets/images/white_king.png"), (80, 80))
        self.whiteKingSmall = pygame.transform.scale(self.whiteKing, (45, 45))
        self.whiteRook = pygame.transform.scale(pygame.image.load("assets/images/white_rook.png"), (80, 80))
        self.whiteRookSmall = pygame.transform.scale(self.whiteRook, (45, 45))
        self.whiteKnight = pygame.transform.scale(pygame.image.load("assets/images/white_knight.png"), (80, 80))
        self.whiteKnightSmall = pygame.transform.scale(self.whiteKnight, (45, 45))
        self.whiteBishop = pygame.transform.scale(pygame.image.load("assets/images/white_bishop.png"), (80, 80))
        self.whiteBishopSmall = pygame.transform.scale(self.whiteBishop, (45, 45))
        self.whitePawn = pygame.transform.scale(pygame.image.load("assets/images/white_pawn.png"), (80, 80))   
        self.whitePawnSmall = pygame.transform.scale(self.whitePawn, (45, 45))
        
        self.blackQueen = pygame.transform.scale(pygame.image.load("assets/images/black_queen.png"), (80, 80))
        self.blackQueenSmall = pygame.transform.scale(self.blackQueen, (45, 45))
        self.blackKing = pygame.transform.scale(pygame.image.load("assets/images/black_king.png"), (80, 80))
        self.blackKingSmall = pygame.transform.scale(self.blackKing, (45, 45))
        self.blackRook = pygame.transform.scale(pygame.image.load("assets/images/black_rook.png"), (80, 80))
        self.blackRookSmall = pygame.transform.scale(self.blackRook, (45, 45))
        self.blackKnight = pygame.transform.scale(pygame.image.load("assets/images/black_knight.png"), (80, 80))
        self.blackKnightSmall = pygame.transform.scale(self.blackKnight, (45, 45))
        self.blackBishop = pygame.transform.scale(pygame.image.load("assets/images/black_bishop.png"), (80, 80))
        self.blackBishopSmall = pygame.transform.scale(self.blackBishop, (45, 45))
        self.blackPawn = pygame.transform.scale(pygame.image.load("assets/images/black_pawn.png"), (80, 80))
        self.blackPawnSmall = pygame.transform.scale(self.blackPawn, (45, 45))
        
        self.whiteImages = [self.whitePawn, self.whiteQueen, self.whiteKing, self.whiteKnight, self.whiteRook, self.whiteBishop]
        self.whiteImagesSmall = [self.whitePawnSmall, self.whiteQueenSmall, self.whiteKingSmall, self.whiteKnightSmall, self.whiteRookSmall, self.whiteBishopSmall]
        self.blackImages = [self.blackPawn, self.blackQueen, self.blackKing, self.blackKnight, self.blackRook, self.blackBishop]
        self.blackImagesSmall = [self.blackPawnSmall, self.blackQueenSmall, self.blackKingSmall, self.blackKnightSmall, self.blackRookSmall, self.blackBishopSmall]
        
        self.whiteOptions = self.checkOptions(self.whitePieces, self.whiteLocations, "white")     #檢查白方所有棋子的合法路徑的，該參數是所有合法路徑的集合
        self.blackOptions = self.checkOptions(self.blackPieces, self.blackLocations, "black")     #檢查黑方所有棋子的合法路徑的，該參數是所有合法路徑的集合
        
        self.pieceList = ["pawn", "queen", "king", "knight", "rook", "bishop"]     #用來作爲顯示棋子的參考index
        self.running = True     #控制游戲窗口，False代表關閉窗口
        
        while(self.running):
            self.timer.tick(self.fps)
            self.counter = (self.counter + 1) % 30     #國王即將被吃的時候格子會閃爍，當counter<15畫出邊框
            self.gameScreen.fill("dark gray")
            self.drawBoard()
            self.drawPieces()
            self.drawCaptured()     #畫出被捕獲的棋子
            self.drawCheck()     #畫出國王即將被吃的時候格子的閃爍
            
            if self.selection != 100:     #當有棋手選擇棋子的時候，在熒幕上畫出該棋子可以移動的路徑
                self.validMoves = self.checkValidMoves()
                self.drawValid(self.validMoves)
                
            if self.turnStep == 2:     #當棋手處於等待狀態
                self.returnCheck = self.server.CheckTurns(self.playerName)     #詢問server是否輪到己方移動的回合
                
                if self.chessColor == "black":
                    self.whiteLocations = list(map(tuple,self.server.CheckWhiteLocation()))     #詢問server白棋子的最新位置
                    self.blackLocations = list(map(tuple,self.server.CheckBlackLocation()))     #詢問server黑棋子的最新位置
                else:
                    tempWhite = list(map(tuple,self.server.CheckWhiteLocation()))
                    
                    for i in range (len(tempWhite)):
                        temp = list(tempWhite[i])
                        temp[0] = 7 - temp[0]
                        temp[1] = 7 - temp[1]
                        tempWhite[i] = tuple(temp)
                    self.whiteLocations = tempWhite
                    tempBlack = list(map(tuple,self.server.CheckBlackLocation()))
                    
                    for i in range (len(tempBlack)):
                        temp = list(tempBlack[i])
                        temp[0] = 7 - temp[0]
                        temp[1] = 7 - temp[1]
                        tempBlack[i] = tuple(temp)
                    self.blackLocations = tempBlack
                self.updatedCapturedPieces = self.server.CheckCapturedPieces(self.playerName)     #詢問server被捕獲的棋子
            
            if self.updatedCapturedPieces != 100 and self.chessColor == "white":     #如果server回傳被捕獲的棋子不是默認參數，默認參數代表沒棋子被捕獲
                self.capturedPiecesBlack.append(self.whitePieces[self.updatedCapturedPieces])     #把被捕獲到的棋子加進被捕獲的list，注：capturedPiecesBlack表示黑方捕獲到的白方棋子的list
                self.whitePieces.pop(self.updatedCapturedPieces)     #己方的棋子list剔除被捕獲的棋子
                self.server.ResetCapturedPiecesBlack()     #讓server重置被捕獲的棋子的參數。爲了確保client有收到參數，所以是在client重置，而不是server自己重置
                self.updatedCapturedPieces = 100     #重置client的被捕獲棋子參數
            elif self.updatedCapturedPieces != 100 and self.chessColor == "black":
                self.capturedPiecesWhite.append(self.blackPieces[self.updatedCapturedPieces])
                self.blackPieces.pop(self.updatedCapturedPieces)
                self.server.ResetCapturedPiecesWhite() 
                self.updatedCapturedPieces = 100
            
            self.whiteOptions = self.checkOptions(self.whitePieces, self.whiteLocations, "white")     #因爲剛剛可能有棋子被剔除，所以這邊重新檢查合法路徑。
            self.blackOptions = self.checkOptions(self.blackPieces, self.blackLocations, "black")
                
            if self.returnCheck == "white":     #當server回傳棋手可以移動。注：白方永遠不會收到"black"，黑方永遠不會收到"white"
                self.returnCheck = "not your turn"     #重置參數
                self.turnStep = 0     #turnStep=0表示白方可以開始操作棋子，turnStep=3則黑方可以操作棋子
                self.recordWhiteSec = datetime.now().timestamp()     #記錄回合轉變那一瞬間的當前時間
                self.showTimer = self.leftTime     #顯示時間=剩餘的思考時間
            elif self.returnCheck == "black":
                self.returnCheck = "not your turn"
                self.turnStep = 3
                self.recordBlackSec = datetime.now().timestamp()
                self.showTimer = self.leftTime
            
            self.currentSec = datetime.now().timestamp()     #記錄當前時間。注：這個參數是動態的
            
            if self.showTimer >= 0 and self.chessColor == "white" and not self.gameOver:     #當顯示時間>=0
                self.showTimer = self.leftTime - (int(self.currentSec) - int(self.recordWhiteSec))     #顯示時間(動態)=剩餘的思考時間-(當前時間(動態)-回合轉變那一瞬間的時間)
            elif self.showTimer >= 0 and self.chessColor == "black" and not self.gameOver:     #注：真正拿來判斷游戲剩餘時間用的是showTimer來判斷，不是leftTime
                self.showTimer = self.leftTime - (int(self.currentSec) - int(self.recordBlackSec))     #注：leftTime在回合變更前一直是固定的，而showTimer則是動態的
                
            if self.showTimer == 0 and not self.gameOver:     #當showTimer=0，游戲結束
                
                if self.chessColor == "white":     #如果己方是白方，發送勝利者是黑方給server
                    self.winner = "black"
                    self.server.SaveWinner("black")
                elif self.chessColor == "black":
                    self.winner = "white"
                    self.server.SaveWinner("white")
                self.server.SaveWinStatus(2)     #發送游戲結束原因給server，2代表棋手用完思考時間
                self.winStatus = 2
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:     #如果棋手直接關掉游戲窗口
                    if self.winner == "" and self.chessColor == "white":     #如果己方是白方，發送勝利者是黑方給server
                        self.server.SaveWinner("black")
                    elif self.winner == "" and self.chessColor == "black":
                        self.server.SaveWinner("white")
                    self.server.SaveWinStatus(4)     #發送游戲結束原因給server，4代表棋手惡意退出游戲
                    self.winStatus = 4
                    self.running = False     #結束程式運行
                
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not self.gameOver:     #當棋手點擊滑鼠左鍵
                    xCord = event.pos[0] // 100     #獲取鼠標x坐標，然後除以100
                    yCord = event.pos[1] // 100     #獲取鼠標y坐標，然後除以100
                    clickCords = (xCord, yCord)     #當坐標除以100，然後xy集合成tuple，在點擊棋子時這個參數可以和white/blackLocations的成員參數一樣。
                    
                    if self.turnStep <= 1:     #turnStep<=1，代表白方操作
                        if clickCords == (8, 8) or clickCords == (9, 8):     #當棋手點擊投降
                            self.winner = "black"
                            self.showTimer = -1
                            self.server.SaveWinner("black")     #發送勝利者是黑方給server，注：現在是白方回合
                            self.server.SaveWinStatus(3)     #發送游戲結束原因給server，3代表棋手投降
                            self.winStatus = 3
                        if clickCords in self.whiteLocations:     #當鼠標點擊的坐標和whiteLocations的成員參數一樣。
                            self.selection = self.whiteLocations.index(clickCords)     #白方選擇了一個棋子
                            if self.turnStep == 0:
                                self.turnStep = 1     #turnStep=1表示白方選擇了一個棋子，現在可以開始放置棋子
                        if clickCords in self.validMoves and self.selection != 100:     #當白方選擇了一個棋子且放置的位子是合法的
                            self.whiteLocations[self.selection] = clickCords     #更新選擇的棋子的位置
                            self.leftTime = self.showTimer + self.awardTime     #剩餘時間等於當前顯示時間+獎勵時間，注:這時候回合即將變更
                            self.showTimer = -1     #重置顯示時間
                            if clickCords in self.blackLocations:     #當白方放置棋子的位置有黑方的棋子
                                blackPiece = self.blackLocations.index(clickCords)     #從滑鼠坐標獲取黑方棋子的信息
                                self.capturedPiecesWhite.append(self.blackPieces[blackPiece])     #把被捕獲到的黑方棋子加進白方的捕獲list
                                self.server.SaveCapturedPiecesWhite(blackPiece)     #發送被捕獲的黑方棋子給server
                                if self.blackPieces[blackPiece] == "king":     #如果被捕獲到的黑方棋子是國王
                                    self.winner = "white"
                                    self.server.SaveWinner("white")     #發送勝利者是白方給server，注：現在是白方回合
                                    self.server.SaveWinStatus(1)     #發送游戲結束原因給server，1代表捕獲國王
                                    self.winStatus = 1
                                self.blackPieces.pop(blackPiece)     #黑方棋子list剔除被捕獲到的棋子
                                self.blackLocations.pop(blackPiece)     #黑方棋子位置同樣要剔除被捕獲到的棋子。注：blackPieces和blackLocations是聯動的
                                self.server.ResetDrawStep()     #因爲有捕獲到黑方棋子，所以讓server重置記錄的合棋回合
                            elif clickCords not in self.blackLocations:     #如果這次移動沒有捕獲到黑方棋子，讓server計算一次合棋回合
                                self.server.AddDrawStep()
                            self.server.SaveWhiteLocation(self.whiteLocations, self.chessColor)     #發送最新的白方位置給server
                            self.server.SaveBlackLocation(self.blackLocations, self.chessColor)     #發送最新的黑方位置給server
                            self.whiteOptions = self.checkOptions(self.whitePieces, self.whiteLocations, "white")     #重新檢查所有棋子的合法路徑。
                            self.blackOptions = self.checkOptions(self.blackPieces, self.blackLocations, "black")
                            self.server.SaveTurns(0)     #通知server回合結束
                            self.turnStep = 2     #進入等待狀態
                            self.selection = 100     #重置玩家選擇的棋子的index
                            self.validMoves = []     #重置熒幕顯示的合法路徑的參數
                    
                    if self.turnStep > 2:     #和上面那一段一樣，但是這回輪到黑方操作
                        if clickCords == (8, 8) or clickCords == (9, 8):
                            self.winner = "white"
                            self.showTimer = -1
                            self.server.SaveWinner("white")
                            self.server.SaveWinStatus(3)
                            self.winStatus = 3
                        if clickCords in self.blackLocations:
                            self.selection = self.blackLocations.index(clickCords)
                            if self.turnStep == 3:
                                self.turnStep = 4
                        if clickCords in self.validMoves and self.selection != 100:
                            self.blackLocations[self.selection] = clickCords
                            self.leftTime = self.showTimer + self.awardTime
                            self.showTimer = -1
                            if clickCords in self.whiteLocations:
                                whitePiece = self.whiteLocations.index(clickCords)
                                self.capturedPiecesBlack.append(self.whitePieces[whitePiece])
                                self.server.SaveCapturedPiecesBlack(whitePiece)
                                if self.whitePieces[whitePiece] == "king":
                                    self.winner = "black"
                                    self.server.SaveWinner("black")
                                    self.server.SaveWinStatus(1)
                                    self.winStatus = 1
                                self.whitePieces.pop(whitePiece)
                                self.whiteLocations.pop(whitePiece)
                                self.server.ResetDrawStep()
                            elif clickCords not in self.whiteLocations:
                                self.server.AddDrawStep()
                            self.server.SaveBlackLocation(self.blackLocations, self.chessColor)
                            self.server.SaveWhiteLocation(self.whiteLocations, self.chessColor)
                            self.blackOptions = self.checkOptions(self.blackPieces, self.blackLocations, "black")
                            self.whiteOptions = self.checkOptions(self.whitePieces, self.whiteLocations, "white")
                            self.server.SaveTurns(3)
                            self.turnStep = 2
                            self.selection = 100
                            self.validMoves = []
                            
                if event.type == pygame.KEYDOWN and self.gameOver:
                    if event.key == pygame.K_RETURN:     #當游戲結束且棋手按下enter鍵
                        self.server.ResetTurnStep()     #重置server參數。注：如果server的參數存進json且游戲結束時會清洗該場游戲的所有參數的話，可以直接略過這段重置
                        self.server.ResetWinner()
                        self.server.ResetWinStatus()
                        self.server.ResetWhiteLocation()
                        self.server.ResetBlackLocation()
                        self.server.ResetReady()
                        self.server.ResetDrawStep()
                        self.running = False     #關閉游戲窗口
                        
            if self.winner != "":     #如果winner變數不是空字串，代表游戲結束了
                self.gameOver = True
                self.drawGameOver()
            else:
                self.returnWinCheck = self.server.CheckWinner()     #如果游戲未結束，向server不斷詢問對面操作後的游戲情況是否符合結束條件
                self.returnWinStatus = self.server.CheckWinStatus()
                
                if self.returnWinCheck == "white":
                    self.winner = "white"
                elif self.returnWinCheck == "black":
                    self.winner = "black"
                elif self.returnWinCheck == "draw":
                    self.winner = "draw"
                    
                if self.returnWinStatus != 0:     #記錄游戲結束原因
                    self.winStatus = self.returnWinStatus
                    
            pygame.display.flip()
        pygame.quit()
    #end of run
#end of ChessThread

def Main():
    
    server = xmlrpc.client.ServerProxy("http://127.0.0.1:" + str(PORT))
    username = input("Input your username (whiteUser, blackUser): ")
    color = input("Input your color (white, black): ")
    server.GameReady(username)
    print("Waiting for other player...")
    
    while(1):
        result = str(server.CheckStartGame())
        if result == "game on":
            print("Player ready, game start!")
            gameThread = ChessThread(username, color, server)
            break
#end of Main

if __name__ == '__main__':
    Main()