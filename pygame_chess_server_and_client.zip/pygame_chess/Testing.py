import tkinter as tk
from PIL import Image, ImageTk

# 创建Tkinter窗口
window = tk.Tk()
window.title("对战视窗")

window.resizable(False, False)

# 加载图片，请将图像文件的路径替换为实际路径
image_a = Image.open("assets/images/white_player.png")
image_a = image_a.resize((250, 250))  # 调整图片大小
image_a = ImageTk.PhotoImage(image_a)

image_b = Image.open("assets/images/black_player.png")
image_b = image_b.resize((250, 250))  # 调整图片大小
image_b = ImageTk.PhotoImage(image_b)

# 创建Label元件以显示图片
label_a = tk.Label(window, image=image_a)
label_b = tk.Label(window, image=image_b)

# 创建Label元件以显示文字
text_label = tk.Label(window, text="VS")
text_label.config(font=("Arial", 45))  # 设置文本大小

# 用户名称、胜率、胜场、败场和平手的文本
user_a_label = tk.Label(window, text="玩家A")
user_b_label = tk.Label(window, text="玩家B")

# 设置文本字体大小
user_a_label.config(font=("Arial", 16))
user_b_label.config(font=("Arial", 16))

stats_a_text = "胜率: 75% | 胜场: 5  / 2  / 1 "
stats_b_text = "胜率: 65% | 胜场: 4  / 3  / 2 "
stats_a_label = tk.Label(window, text=stats_a_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")
stats_b_label = tk.Label(window, text=stats_b_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")

# 设置文本字体大小
stats_a_label.config(font=("Arial", 14))
stats_b_label.config(font=("Arial", 14))

# 放置元件在适当的位置
label_a.grid(row=2, column=0)
text_label.grid(row=2, column=1)
label_b.grid(row=2, column=2)

user_a_label.grid(row=3, column=0)
stats_a_label.grid(row=4, column=0)

user_b_label.grid(row=3, column=2)
stats_b_label.grid(row=4, column=2)

# 添加 "思考时间: 180 + 3" 的文本在图片上方中央
total_time_label = tk.Label(window, text="思考时间: 180 + 3", font=("Arial", 24))
total_time_label.grid(row=0, column=1)

# 启动Tkinter主循环
window.mainloop()
