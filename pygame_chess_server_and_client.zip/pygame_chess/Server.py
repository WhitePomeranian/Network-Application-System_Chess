from xmlrpc.server import SimpleXMLRPCServer
from socketserver import ThreadingMixIn
import threading
import json
import uuid

port = 8888
EnableCS = True

class ThreadXMLRPCServer(ThreadingMixIn, SimpleXMLRPCServer):
	pass

class ChessServer:

    users = []
    usernames = []
    rooms = []
  
    def __init__(self):
        self.load_users()
        if(EnableCS):
            self.lock = threading.Lock()
            
    def get_usernames_length(self):
        return len(self.usernames)
        
    def is_in_usernames(self, a_username):
        if a_username in self.usernames:
            return True
        else:
            return False
            
    def load_users(self):
        try:
            with open("assets/database/users.json", "r") as file:
                data = json.load(file)
                self.users = data["users"]
                self.usernames = data["usernames"]
        except FileNotFoundError as e:
            print("Error: %s" % e)
            self.users = []
            self.usernames = []
            exit(1)
            
    def save_users(self):
        data = {
            "usernames": self.usernames,
            "users": self.users
        }
        with open("assets/database/users.json", 'w') as file:
            json.dump(data, file)
            
    def save_rooms(self):
        data = {
            'rooms': self.rooms
        }
        with open("assets/database/rooms.json", 'w') as file:
            json.dump(data, file)
            
    def load_rooms(self):
        try:
            with open("assets/database/rooms.json", "r") as file:
                data = json.load(file)
                self.rooms = data["rooms"]
        except FileNotFoundError as e:
            print("Error: %s" % e)
            self.rooms = []
            exit(1)  
            
    def get_user_stats(self, a_user):
        if(EnableCS):
            with self.lock:
                self.load_users()
                a_index = self.usernames.index(a_user) 
                    
        return {"win": self.users[a_index]["win"], "lose": self.users[a_index]["lose"], "draw": self.users[a_index]["draw"]}
        
    def get_opponent_room_index(self, a_opponent):
        for i in range(len(self.rooms)):
            if self.rooms[i]["user"] == a_opponent:
                return i
        return False
        
    def get_opponent_room(self, a_opponent):
        if(EnableCS):
            with self.lock:
                self.load_rooms()
                a_index = self.get_opponent_room_index(a_opponent)
        
        return self.rooms[a_index]
    
    def get_user_room_index(self, user):
        for i in range(len(self.rooms)):
            if self.rooms[i]["user"] == user:
                return i
        return False   

    def get_user_room(self, a_user):
        if(EnableCS):
            with self.lock:
                self.load_rooms()
                a_index = self.get_user_room_index(a_user)
        
        return self.rooms[a_index]    
          
    def update_opponent(self, a_user, a_opponent):
        if(EnableCS):
            with self.lock:
                self.load_rooms()
                a_index = self.get_user_room_index(a_user)
                self.rooms[a_index]["opponent"] = a_opponent
                self.save_rooms()
        return True
        
    def delete_opponent(self, a_user):
        if(EnableCS):
            with self.lock:
                self.load_rooms()
                a_index = self.get_user_room_index(a_user)
                self.rooms[a_index]["opponent"] = ""
                self.save_rooms()
                
        return self.rooms
            
    #register Start           
    def register(self, a_username, a_password):
        if(EnableCS):
            with self.lock:
                self.usernames.append(a_username)
                self.users.append({"username": a_username, "password": a_password, "online_state": False, "win": '0', "lose": '0', "draw": '0'})
                self.save_users()

        return True
    #register  End

    #login  Start
    def login(self, a_username, a_password):
        if(EnableCS):
            with self.lock:
                index = self.usernames.index(a_username)
                if self.users[index]["password"] != a_password:
                    return "密碼錯誤!"
                elif self.users[index]["online_state"] != False: 
                    return "該帳號已被其他使用者登入!"
                else:
                    self.users[index]["online_state"] = True
                    self.save_users()
        return "登入成功"
    #login  End

    #logout Start
    def logout(self, a_username):
        if(EnableCS):
            with self.lock:
                index = self.usernames.index(a_username)
                self.users[index]["online_state"] = False
                self.save_users()
        return True
    #logout End
    
    #create Start          
    def create(self, a_color, a_thought_time, a_extra_second, user, a_datetime):
        
        if(EnableCS):
            with self.lock:
                self.rooms.append({"id": str(uuid.uuid4()), "color": a_color, "thought_time": a_thought_time, "extra_second": a_extra_second, "user": user, "datetime": a_datetime, "opponent": ""})
                self.save_rooms()
        return True
    #create End
    
    #subject Start
    def subject(self):
        if(EnableCS):
            with self.lock:
                self.load_rooms()
                    
        return self.rooms
    #subject End

if __name__ == "__main__":
    chess_server = ChessServer()
    server = ThreadXMLRPCServer(("localhost", port))
    server.register_instance(chess_server)
    try:
        print("使用Ctrl + c以退出...")
        server.serve_forever()
    except KeyboardInterrupt:
        print("伺服器退出")