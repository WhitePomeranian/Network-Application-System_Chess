import sys
import getpass
import socket
import xmlrpc.client
import datetime
import unicodedata
import tkinter as tk
from tkinter import scrolledtext, messagebox, ttk
import pygame
from PIL import Image, ImageTk


port = 8888
user = None
rooms = []

class window:
    
    login_window = None
    register_window = None
    
    lobby = None
    l_frame = None
    l_title_label = None
    l_room_box = None
    reset_button = None
    logout_button = None
    create_button = None
    
    create_window = None
    
    room_window = None
    rule_label = None
    versus_label = None
    black_image = None
    white_image = None
    random_image = None
    black_label = None
    white_label = None
    random1_label = None
    random2_label = None
    player1_label = None
    player2_label = None
    player1_stats_label = None
    player2_stats_label = None
    exit_button = None
        
    
    def __init__(self):
        self.open_login_window()
        
    def refresh_lobby(self):
        try:
            print("Refreshing lobby...") 
            self.w_subject()
            self.lobby.after(60000, self.refresh_lobby)
        except:
            print("Stop refreshing lobby!")
        
    def display_message(self, msg, position):
        position.config(state=tk.NORMAL)
        position.delete(1.0, tk.END)
        position.insert(tk.END, msg) 
        position.config(state=tk.DISABLED)
               
    def open_login_window(self):
    

        self.login_window = tk.Tk()
        self.login_window.title("登入")
        
        window_width = 350
        window_height = 250
        
        screen_width = self.login_window .winfo_screenwidth()
        screen_height = self.login_window .winfo_screenheight()

        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        

        self.login_window.geometry(f"{window_width}x{window_height}+{x}+{y}")
    
        self.login_window.resizable(False, False)

        username_label = tk.Label(self.login_window, text="用戶名:")
        username_label.pack()
        username_entry = tk.Entry(self.login_window)
        username_entry.pack()
        
        password_label = tk.Label(self.login_window, text="密碼:")
        password_label.pack()
        password_entry = tk.Entry(self.login_window, show="*")
        password_entry.pack()
        
        login_button = tk.Button(self.login_window, text="確定登入", command=lambda : self.w_login(username_entry.get(), password_entry.get(), message_text))
        login_button.pack(pady=20)

        
        message_label = tk.Label(self.login_window, text="提示訊息:")
        message_label.pack(pady=10)
        
        message_text = tk.Text(self.login_window, height=1, width=30)
        message_text.pack()
        message_text.config(state=tk.DISABLED)
        
                
        register_button = tk.Button(self.login_window, text="註冊", command=self.open_register_window)
        register_button.pack(pady=5)

        
    
    
    def w_login(self, a_username, a_password, a_position):
            global user
        
            if len(a_username) == 0:
                msg = "請輸入使用者名稱"
                self.display_message(msg, a_position)
                return
                
            if len(a_password) == 0:
                msg = "請輸入密碼"
                self.display_message(msg, a_position)
                return
            
            if not server.is_in_usernames(a_username):
                msg = "不存在該使用者"
                self.display_message(msg, a_position)
                return
                
            msg = server.login(a_username, a_password)
            if msg == "登入成功":
                user = a_username
                self.login_window.destroy()
                self.open_lobby_window()
            else:
                self.display_message(msg, a_position)

    def open_register_window(self):
    
        self.register_window = tk.Toplevel(self.login_window)       
        self.register_window.title("註冊")
        
        window_width = 350
        window_height = 250
        
        screen_width = self.register_window .winfo_screenwidth()
        screen_height = self.register_window .winfo_screenheight()

        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        
 
        self.register_window.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.register_window.resizable(False, False)
        
 
        username_label = tk.Label(self.register_window, text="用戶名(至多為16個字元):")
        username_label.pack()
        username_entry = tk.Entry(self.register_window)
        username_entry.pack()
        
        password_label = tk.Label(self.register_window, text="密碼:")
        password_label.pack()
        password_entry = tk.Entry(self.register_window, show="*")
        password_entry.pack()
        
        register_button = tk.Button(self.register_window, text="確定註冊", command=lambda : self.w_register(username_entry.get(), password_entry.get(), message_text))
        register_button.pack(pady=20)
        
        message_label = tk.Label(self.register_window, text="提示訊息:")
        message_label.pack(pady=10)
        
        message_text = tk.Text(self.register_window, height=1, width=40)
        message_text.pack()
        message_text.config(state=tk.DISABLED)
        
    def w_register(self, a_username, a_password, a_position):
    
        if len(a_username) == 0:
            msg = "請輸入使用者名稱"
            self.display_message(msg, a_position)
            return
            
        if not a_username.isalnum():
            msg = "使用者名稱只限輸入中文或字母或數字"
            self.display_message(msg, a_position)
            return
             
        if len(a_username) > 16:
           msg = "使用者名稱至多為16個字元"
           self.display_message(msg, a_position)
           return

        if not server.is_in_usernames(a_username):
        
            if len(a_password) == 0:
                msg = "請輸入密碼"
                self.display_message(msg, a_position)
                return
            
            if len(a_password) < 8:
                msg = "密碼至少為8個字元"
                self.display_message(msg, a_position)
                return
            elif len(a_password) > 16:
                msg = "密碼至多為16個字元"
                self.display_message(msg, a_position)
                return
            
            server.register(a_username, a_password)
            msg = "註冊成功!"
            messagebox.showinfo("提示", msg)
            self.register_window.destroy()
            return                
        else:
            msg = "該使用者名稱已經被註冊"
            self.display_message(msg, a_position)
            return 
            
    def open_lobby_window(self):
        
        global user
        
        self.lobby = tk.Tk()
        self.lobby.title("大廳 (每一分鐘會自動重新整理)")
        
        window_width = 950
        window_height = 500
        
        screen_width = self.lobby.winfo_screenwidth()
        screen_height = self.lobby.winfo_screenheight()

        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        
        self.lobby.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.lobby.resizable(False, False)

        self.l_frame = tk.Frame(self.lobby)
        self.l_frame.pack(padx=10, pady=10)
          
        self.l_title_label = tk.Label(self.l_frame, text=f"您好! {user}", font=("Helvetica", 12, "bold"))
        self.l_title_label.pack()
        
        
        self.reset_button = tk.Button(self.l_frame, text="重新整理", command=self.refresh_lobby)
        self.reset_button.pack(side=tk.LEFT, padx=10)
        
        self.logout_button = tk.Button(self.l_frame, text="登出", command=self.w_logout)
        self.logout_button.pack(side=tk.LEFT)

        self.l_room_box = scrolledtext.ScrolledText(self.lobby, wrap=tk.NONE, width=300, height=22)
        self.l_room_box.pack(padx=10, pady=0)

        self.create_button = tk.Button(self.lobby, text="建立房間", command=self.open_create_window)
        self.create_button.pack(pady=10)
        
        self.message_label = tk.Label(self.lobby, text="提示訊息:")
        self.message_label.pack(pady=10)
        
        self.message_text = tk.Text(self.lobby, height=1, width=100)
        self.message_text.pack()
        self.message_text.config(state=tk.DISABLED) 

        self.w_subject()
        self.refresh_lobby()
        
        
    def w_logout(self):
    
        global user
        server.logout(user)
        user = None
        msg = "登出成功!"
        messagebox.showinfo("提示", msg)
        self.lobby.destroy()
        
    def open_create_window(self):
    
        self.create_window = tk.Toplevel(self.lobby)
        self.create_window.title("建立房間")
        
        window_width = 350
        window_height = 300
        
        screen_width = self.create_window.winfo_screenwidth()
        screen_height = self.create_window.winfo_screenheight()

        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        
        self.create_window.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.create_window.resizable(False, False)

        thought_time_frame = tk.Frame(self.create_window)
        thought_time_frame.pack(side=tk.TOP, pady=10)

        thought_time_label = tk.Label(thought_time_frame, text="思考時間:")
        thought_time_label.pack(side=tk.LEFT)

        thought_time_box = ttk.Combobox(thought_time_frame, values=["%-3d" % 1, "%-3d" % 3, "%-3d" % 5, "%-3d" % 10, "%-3d" % 15, "%-3d" % 30, "%-3d" % 60, "%-3d" % 120, "%-3d" % 150, "%-3d" % 180], width=3, state="readonly")
        thought_time_box.set("%-3d" % 30)
        thought_time_box.pack(side=tk.LEFT)
        
        extra_time_frame = tk.Frame(self.create_window)
        extra_time_frame.pack(side=tk.TOP, pady=15)

        extra_time_label = tk.Label(extra_time_frame, text="時間獎勵:")
        extra_time_label.pack(side=tk.LEFT)
        
        extra_second_spinbox = tk.Spinbox(extra_time_frame, from_=0, to=30, width=2, wrap=True, state="readonly")
        extra_second_spinbox.pack(side=tk.LEFT)
        tk.Label(extra_time_frame, text="秒").pack(side=tk.LEFT)

       
        color_frame = tk.Frame(self.create_window)
        color_frame.pack(side=tk.TOP, pady=15)

        color_label = tk.Label(color_frame, text="對弈方:")
        color_label.pack(side=tk.LEFT)
        
       
        color_box = ttk.Combobox(color_frame, values=["隨機", "黑色", "白色"], width=5, state="readonly")
        color_box.set("隨機")
        color_box.pack(side=tk.LEFT)
                
        confirm_button = tk.Button(self.create_window, text="確定", command=lambda: self.w_create(color_box.get(), thought_time_box.get(), extra_second_spinbox.get(), message_text))
        confirm_button.pack(pady=10)
        
        message_label = tk.Label(self.create_window, text="提示訊息:")
        message_label.pack(pady=10)
        
        message_text = tk.Text(self.create_window, height=1, width=30)
        message_text.pack()
        message_text.config(state=tk.DISABLED)
        
    def w_create(self, a_color, a_thought_time, a_extra_second, a_position):
            
        current_datetime = datetime.datetime.now()     
        server.create(a_color, a_thought_time, a_extra_second, user, current_datetime.strftime("%Y-%m-%d %H:%M:%S"))
        self.create_window.destroy()
        self.lobby.destroy()
        self.open_room_window(a_color, a_thought_time, a_extra_second)
        
    def w_subject(self):
        global user, rooms
            
        self.l_room_box.config(state=tk.NORMAL)
        self.l_room_box.delete(1.0, tk.END)
        
        rooms = server.subject()
        
        for i, room_data in enumerate(rooms):
            
            formatted_text = "   思考時間: %3s 分鐘   |   獎勵時間: %2s 秒   |   對弈者(%s): %s                     %s" % (room_data["thought_time"].strip(), room_data["extra_second"], room_data["color"], align_text(room_data["user"], 16), room_data["datetime"])
            
            join_button = tk.Button(self.l_room_box, text="對弈", bd=0, fg="green", font=("Helvetica", 12), command=lambda opponent=room_data["user"]: self.w_enter(opponent))
            self.l_room_box.window_create(tk.END, window=join_button)
            
            self.l_room_box.insert(tk.END, formatted_text)
   
            self.l_room_box.insert(tk.END, "\n")

        self.l_room_box.config(state=tk.DISABLED)
        
    def open_room_window(self, a_color, a_thought_time, a_extra_second):

        global user
        
        self.room_window = tk.Tk()
        self.room_window.title("等待其他人加入...")
        self.room_window.geometry("1050x400")
        
        self.room_window.resizable(False, False) 
        
        self.rule_label = tk.Label(self.room_window, text="思考時間: %3s + %-2s" % (a_thought_time.strip(), a_extra_second), font=("Arial", 24))
        self.rule_label.grid(row=6, column=1)
        
        self.versus_label = tk.Label(self.room_window, text="VS")
        self.versus_label.config(font=("Arial", 45))
        
                
        self.black_image = Image.open("assets/images/black_player.png")
        self.black_image = self.black_image.resize((280, 250))
        self.black_image = ImageTk.PhotoImage(self.black_image)

        self.white_image = Image.open("assets/images/white_player.png")
        self.white_image = self.white_image.resize((280, 250))
        self.white_image = ImageTk.PhotoImage(self.white_image)
        
        self.random_image = Image.open("assets/images/random_player.png")
        self.random_image = self.random_image.resize((280, 250))
        self.random_image = ImageTk.PhotoImage(self.random_image)
        
        self.black_label = tk.Label(self.room_window, image= self.black_image)
        self.white_label = tk.Label(self.room_window, image=self.white_image)
 
        self.random1_label = tk.Label(self.room_window, image=self.random_image)
        self.random2_label = tk.Label(self.room_window, image=self.random_image)

        if a_color == "黑色":
            self.black_label.grid(row=3, column=0)
            self.versus_label.grid(row=3, column=1)
            self.white_label.grid(row=3, column=2)
        elif a_color == "白色":
            self.white_label.grid(row=3, column=0)
            self.versus_label.grid(row=3, column=1)
            self.black_label.grid(row=3, column=2) 
        else:   
            self.random1_label.grid(row=2, column=0)
            self.versus_label.grid(row=2, column=1)
            self.random2_label.grid(row=2, column=2)

        self.player1_label = tk.Label(self.room_window, text=user)
        self.player1_label.config(font=("Arial", 24))       
        self.player1_label.grid(row=4, column=0)

        self.player2_label = tk.Label(self.room_window, text="等待對手...")
        self.player2_label.config(font=("Arial", 24))       
        self.player2_label.grid(row=4, column=2)
              
        player2_stats_text = "勝率:   -   |   Win: - / Lose: - / Draw: -"
        self.player2_stats_label = tk.Label(self.room_window, text=player2_stats_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")       
        self.player2_stats_label.grid(row=5, column=2)

        player1_stats = server.get_user_stats(user)
        player1_game_sum = int(player1_stats["win"]) + int(player1_stats["lose"]) + int(player1_stats["draw"])
        try:
            player1_win_rate = int(player1_stats["win"]) / float(player1_game_sum)
        except ZeroDivisionError:
            player1_win_rate = 0.0
            
        player1_stats_text = "勝率: %.2f   |   Win: %s / Lose: %s / Draw: %s" % (player1_win_rate, player1_stats["win"], player1_stats["lose"], player1_stats["draw"])
        self.player1_stats_label = tk.Label(self.room_window, text=player1_stats_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")       
        self. player1_stats_label.grid(row=5, column=0)

        self.room_window.after(1000, self.update_opponent)

        
    def update_opponent(self):
        try:
            print("Refreshing opponent...")
            a_room = server.get_user_room(user)

            if(a_room["opponent"] != ""):
                self.room_window.title("%s進入房間" % a_room["opponent"])
                player2_stats = server.get_user_stats(a_room["opponent"])
                player2_game_sum = int(player2_stats["win"]) + int(player2_stats["lose"]) + int(player2_stats["draw"])
                try:
                    player2_win_rate = int(player2_stats["win"]) / float(player2_game_sum)
                except ZeroDivisionError:
                    player2_win_rate = 0.0
                    
                player2_stats_text = "勝率: %.2f   |   Win: %s / Lose: %s / Draw: %s" % (player2_win_rate, player2_stats["win"], player2_stats["lose"], player2_stats["draw"])
                self.player2_stats_label.config(text=player2_stats_text)
                self.player2_label.config(text=a_room["opponent"])
                
            else:
                    
                player2_stats_text = "勝率:   -   |   Win: - / Lose: - / Draw: -"
                self.player2_stats_label.config(text=player2_stats_text)
                self.player2_label.config(text="等待對手...")
                self.room_window.title("等待其他人加入...")
 
            self.room_window.after(1000, self.update_opponent)
        except:
            print("Stop refreshing opponent!")
    
    def w_enter(self, a_opponent):
    
        global user
    
        self.lobby.destroy()
    
        a_room = server.get_opponent_room(a_opponent)
        
        self.room_window = tk.Tk()
        self.room_window.title("%s的房間" % a_room["user"])
        self.room_window.geometry("1050x400")
        
        self.room_window.resizable(False, False) 
        
        self.rule_label = tk.Label(self.room_window, text="思考時間: %3s + %-2s" % (a_room["thought_time"].strip(), a_room["extra_second"]), font=("Arial", 24))
        self.rule_label.grid(row=6, column=1)
        
        self.versus_label = tk.Label(self.room_window, text="VS")
        self.versus_label.config(font=("Arial", 45))
 
        self.black_image = Image.open("assets/images/black_player.png")
        self.black_image = self.black_image.resize((280, 250))
        self.black_image = ImageTk.PhotoImage(self.black_image)

        self.white_image = Image.open("assets/images/white_player.png")
        self.white_image = self.white_image.resize((280, 250))
        self.white_image = ImageTk.PhotoImage(self.white_image)
        
        self.random_image = Image.open("assets/images/random_player.png")
        self.random_image = self.random_image.resize((280, 250))
        self.random_image = ImageTk.PhotoImage(self.random_image)
        
        self.black_label = tk.Label(self.room_window, image= self.black_image)
        self.white_label = tk.Label(self.room_window, image=self.white_image)
 
        self.random1_label = tk.Label(self.room_window, image=self.random_image)
        self.random2_label = tk.Label(self.room_window, image=self.random_image)
        
        if a_room["color"] == "白色":
            self.black_label.grid(row=3, column=0)
            self.versus_label.grid(row=3, column=1)
            self.white_label.grid(row=3, column=2)
        elif a_room["color"] == "黑色":
            self.white_label.grid(row=3, column=0)
            self.versus_label.grid(row=3, column=1)
            self.black_label.grid(row=3, column=2) 
        else:   
            self.random1_label.grid(row=2, column=0)
            self.versus_label.grid(row=2, column=1)
            self.random2_label.grid(row=2, column=2)
        
        self.player1_label = tk.Label(self.room_window, text=user)
        self.player1_label.config(font=("Arial", 24))       
        self.player1_label.grid(row=4, column=0)
        
        self.player2_label = tk.Label(self.room_window, text=a_opponent)
        self.player2_label.config(font=("Arial", 24))       
        self.player2_label.grid(row=4, column=2)    
        
        player1_stats = server.get_user_stats(user)
        player1_game_sum = int(player1_stats["win"]) + int(player1_stats["lose"]) + int(player1_stats["draw"])
        try:
            player1_win_rate = int(player1_stats["win"]) / float(player1_game_sum)
        except ZeroDivisionError:
            player1_win_rate = 0.0
            
        player1_stats_text = "勝率: %.2f   |   Win: %s / Lose: %s / Draw: %s" % (player1_win_rate, player1_stats["win"], player1_stats["lose"], player1_stats["draw"])
        self.player1_stats_label = tk.Label(self.room_window, text=player1_stats_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")       
        self. player1_stats_label.grid(row=5, column=0)
        
        player2_stats = server.get_user_stats(a_opponent)
        player2_game_sum = int(player2_stats["win"]) + int(player2_stats["lose"]) + int(player2_stats["draw"])
        try:
            player2_win_rate = int(player2_stats["win"]) / float(player2_game_sum)
        except ZeroDivisionError:
            player2_win_rate = 0.0
            
        player2_stats_text = "勝率: %.2f   |   Win: %s / Lose: %s / Draw: %s" % (player2_win_rate, player2_stats["win"], player2_stats["lose"], player2_stats["draw"])
        self.player2_stats_label = tk.Label(self.room_window, text=player2_stats_text, font=("Arial", 14), justify='center', anchor='n', padx=20, fg="green")       
        self.player2_stats_label.grid(row=5, column=2)
        server.update_opponent(a_opponent, user)
        
        self.exit_button = tk.Button(self.room_window, text="離開", bd=0, fg="red", font=("Helvetica", 12), command=lambda : self.exit_room(a_opponent))
        self.exit_button.grid(row=7, column=1)
        
    def exit_room(self, a_opponent):
        server.delete_opponent(a_opponent)
        self.room_window.destroy()
        self.open_lobby_window()
        
class Chess:
   
    # 成員變數
    game_screen = None
    screen_size = None
    game_icon = None
    piece_font = None
    
    left_padding = None
    top_padding = None
    
    white_king_text = "k"
    white_queen_text = "q"
    white_rook_text = "r"
    white_bishop_text = "b"
    white_knight_text = "n"
    white_pawn_text = "p"
    
    black_king_text = "l"
    black_queen_text = "w"
    black_rook_text = "t"
    black_bishop_text = "v"
    black_knight_text = "m"
    black_pawn_text = "o"
    
    piece_types = ["king", "queen", "rook", "bishop", "knight", "pawn"]
    pieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]
    white_piece_images = []
    black_piece_images = []
    black_locations = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
    white_locations = [(0, 7), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (7, 6)]   
    # 成員變數
    
    def __init__(self):
        pygame.init() # 啟動Pygame環境
        self.create_root()
        self.create_board()
        self.create_pieces()
        self.run_game()
      
    def create_root(self):           
        self.game_screen = pygame.display.set_mode([1500, 750])
        self.game_screen.fill((255, 255, 255))
        pygame.display.set_caption("網路程式設計專題")
        background = pygame.image.load("assets/images/background.jpg")
        self.game_screen.blit(background, (0, 0))
        self.game_icon = pygame.image.load("assets/images/game_icon.png")
        pygame.display.set_icon(self.game_icon)
          
    def create_board(self):
        
        self.piece_font = pygame.font.Font("assets/merid_tt/MERIFONT.TTF", 75)       
        self.draw_board()
        
    def create_pieces(self):
        
        width = 30
        high = 30

        # 白棋
        white_king = self.piece_font.render(self.white_king_text, True, "black")
        white_queen = self.piece_font.render(self.white_queen_text, True, "black")
        white_rook  = self.piece_font.render(self.white_rook_text, True, "black")
        white_knight = self.piece_font.render(self.white_knight_text, True, "black")
        white_bishop = self.piece_font.render(self.white_bishop_text, True, "black")
        white_pawn = self.piece_font.render(self.white_pawn_text, True, "black")
        # 白棋
        
        # 黑棋
        black_queen = self.piece_font.render(self.black_queen_text, True, "black")
        black_king = self.piece_font.render(self.black_king_text, True, "black")
        black_rook = self.piece_font.render(self.black_rook_text, True, "black")
        black_knight = self.piece_font.render(self.black_knight_text, True, "black")
        black_bishop = self.piece_font.render(self.black_bishop_text, True, "black")
        black_pawn = self.piece_font.render(self.black_pawn_text, True, "black")
        # 黑棋
        
        self.white_piece_images = [white_king, white_queen, white_rook, white_bishop, white_knight, white_pawn]
        self.black_piece_images = [black_king, black_queen, black_rook, black_bishop, black_knight, black_pawn]
        self.draw_pieces()
        
    # draw_board Start
    def draw_board(self):
    
        self.left_padding = 200
        self.top_padding = (750 - 640) / 2
        
        x = 0
        y = self.top_padding       
        color_flag = True
        
        for i in range(64):
            
            width = 80
            high = 80
            if i % 8 == 0:
                x = self.left_padding
                if i != 0:
                    y += high
            else:
                x += width
                color_flag = not color_flag
            
            if color_flag:
                pygame.draw.rect(self.game_screen, (255, 228, 196), [x, y, width, high])
            else:
                pygame.draw.rect(self.game_screen, (205, 102, 29), [x, y, width, high])
    # draw_board End
    
    # draw_pieces Start    
    def draw_pieces(self):
        
        width = 80
        high = 80
        
        for i in range (len(self.pieces)):
            
            x = self.white_locations[i][0] * width + 2.5 + self.left_padding
            y = self.white_locations[i][1] * width + 2.5 + self.top_padding
        
            type_index = self.piece_types.index(self.pieces[i])
            self.game_screen.blit(self.white_piece_images[type_index], (x, y))
            
            x = self.black_locations[i][0] * width + 2.5 + self.left_padding
            y = self.black_locations[i][1] * width + 2.5 + self.top_padding
            type_index = self.piece_types.index(self.pieces[i])
            self.game_screen.blit(self.black_piece_images[type_index], (x, y))
    # draw_pieces End
       
    def run_game(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
          
            pygame.display.update()
            
def align_text(text, width):
    text_width = sum(1 + (unicodedata.east_asian_width(char) in ['W', 'F']) for char in text)
    padding = max(0, width - text_width)
    return text + " " * padding
    

def is_wide_character(char):
    width = unicodedata.east_asian_width(char)
    return width in ('W', 'F', 'A')       
         
if __name__ == "__main__":

    if len(sys.argv) < 2:
            print("Usage: Client.py ServerIP")
            exit(1)
        
    server = xmlrpc.client.ServerProxy("http://" + sys.argv[1] + ":" + str(port))
    w = window()
    w.login_window.mainloop()
    #game = Chess()
    if user:
        server.logout(user)

'''
white_king_small = pygame.transform.scale(white_king, (width, high))
white_queen_small = pygame.transform.scale(white_queen, (width, high))
white_rook_small = pygame.transform.scale(white_rook, (width, high))
white_bishop_small = pygame.transform.scale(white_bishop, (width, high))
white_knight_small = pygame.transform.scale(white_knight, (width, high))
white_pawn_small = pygame.transform.scale(white_pawn, (width, high))
'''

'''
black_queen_small = pygame.transform.scale(black_queen, (width, high))
black_king_small = pygame.transform.scale(black_king, (width, high))
black_rook_small = pygame.transform.scale(black_rook, (width, high))
black_knight_small = pygame.transform.scale(black_knight, (width, high))
black_bishop_small = pygame.transform.scale(black_bishop, (width, high))
black_pawn_small = pygame.transform.scale(black_pawn, (width, high))
'''