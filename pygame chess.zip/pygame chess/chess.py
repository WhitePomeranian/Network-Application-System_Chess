import pygame

pygame.init()
gameScreen = pygame.display.set_mode([1000,900])
pygame.display.set_caption("網路程式設計專題")
pygameIcon = pygame.image.load("assets/images/black_queen.png")
pygame.display.set_icon(pygameIcon)
font = pygame.font.Font("freesansbold.ttf", 20)
bigFont = pygame.font.Font("freesansbold.ttf", 50)
mediumFont = pygame.font.Font("freesansbold.ttf", 35)
timer = pygame.time.Clock()
counter = 0
fps = 60
winner = ""
gameOver = False

whitePieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]
whiteLocations = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
blackPieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]
blackLocations = [(0, 7), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (7, 6)]
capturedPiecesWhite = []
capturedPiecesBlack = []
turnStep = 0
selection = 100
validMoves = []

whiteQueen = pygame.transform.scale(pygame.image.load("assets/images/white_queen.png"), (80, 80))
whiteQueenSmall = pygame.transform.scale(whiteQueen, (45, 45))
whiteKing = pygame.transform.scale(pygame.image.load("assets/images/white_king.png"), (80, 80))
whiteKingSmall = pygame.transform.scale(whiteKing, (45, 45))
whiteRook = pygame.transform.scale(pygame.image.load("assets/images/white_rook.png"), (80, 80))
whiteRookSmall = pygame.transform.scale(whiteRook, (45, 45))
whiteKnight = pygame.transform.scale(pygame.image.load("assets/images/white_knight.png"), (80, 80))
whiteKnightSmall = pygame.transform.scale(whiteKnight, (45, 45))
whiteBishop = pygame.transform.scale(pygame.image.load("assets/images/white_bishop.png"), (80, 80))
whiteBishopSmall = pygame.transform.scale(whiteBishop, (45, 45))
whitePawn = pygame.transform.scale(pygame.image.load("assets/images/white_pawn.png"), (80, 80))   
whitePawnSmall = pygame.transform.scale(whitePawn, (45, 45))

blackQueen = pygame.transform.scale(pygame.image.load("assets/images/black_queen.png"), (80, 80))
blackQueenSmall = pygame.transform.scale(blackQueen, (45, 45))
blackKing = pygame.transform.scale(pygame.image.load("assets/images/black_king.png"), (80, 80))
blackKingSmall = pygame.transform.scale(blackKing, (45, 45))
blackRook = pygame.transform.scale(pygame.image.load("assets/images/black_rook.png"), (80, 80))
blackRookSmall = pygame.transform.scale(blackRook, (45, 45))
blackKnight = pygame.transform.scale(pygame.image.load("assets/images/black_knight.png"), (80, 80))
blackKnightSmall = pygame.transform.scale(blackKnight, (45, 45))
blackBishop = pygame.transform.scale(pygame.image.load("assets/images/black_bishop.png"), (80, 80))
blackBishopSmall = pygame.transform.scale(blackBishop, (45, 45))
blackPawn = pygame.transform.scale(pygame.image.load("assets/images/black_pawn.png"), (80, 80))
blackPawnSmall = pygame.transform.scale(blackPawn, (45, 45))

whiteImages = [whitePawn, whiteQueen, whiteKing, whiteKnight, whiteRook, whiteBishop]
whiteImagesSmall = [whitePawnSmall, whiteQueenSmall, whiteKingSmall, whiteKnightSmall, whiteRookSmall, whiteBishopSmall]
blackImages = [blackPawn, blackQueen, blackKing, blackKnight, blackRook, blackBishop]
blackImagesSmall = [blackPawnSmall, blackQueenSmall, blackKingSmall, blackKnightSmall, blackRookSmall, blackBishopSmall]

pieceList = ["pawn", "queen", "king", "knight", "rook", "bishop"]

def drawBoard():
    
    for i in range (32):
        column = i % 4
        row = i // 4
        if row % 2 == 0:
            pygame.draw.rect(gameScreen, "light gray", [600 - (column * 200), row * 100, 100, 100])
        else:
            pygame.draw.rect(gameScreen, "light gray", [700 - (column * 200), row * 100, 100, 100])
            
        pygame.draw.rect(gameScreen, "gray", [0, 800, 1000, 100])
        pygame.draw.rect(gameScreen, "gold", [0, 800, 1000, 100], 5)
        pygame.draw.rect(gameScreen, "gold", [800, 0, 200, 900], 5)
        statusText = ["White: Select a piece to move!", "White: Select a destination!", "Black: Select a piece to move!", "Black: Select a destination!"]
        gameScreen.blit(bigFont.render(statusText[turnStep], True, "black"), (20, 827))
        
        for i in range (9):
            pygame.draw.line(gameScreen, "black", (0, 100 * i), (800, 100 * i), 2)
            pygame.draw.line(gameScreen, "black", (100 * i, 0), (100 * i, 800), 2)
            
        gameScreen.blit(mediumFont.render("Surrender", True, "black"), (813, 833))
#end of drawBoard

def drawPieces():
    
    for i in range (len(whitePieces)):
        index = pieceList.index(whitePieces[i])
        gameScreen.blit(whiteImages[index], (whiteLocations[i][0] * 100 + 10, whiteLocations[i][1] * 100 + 10))
        
        if turnStep < 2:
            if selection == i:
                pygame.draw.rect(gameScreen, "red", [whiteLocations[i][0] * 100 + 1, whiteLocations[i][1] * 100 + 1, 100, 100], 2)
            
    for i in range (len(blackPieces)):
        index = pieceList.index(blackPieces[i])
        gameScreen.blit(blackImages[index], (blackLocations[i][0] * 100 + 10, blackLocations[i][1] * 100 + 10))
        
        if turnStep >= 2:
            if selection == i:
                pygame.draw.rect(gameScreen, "blue", [blackLocations[i][0] * 100 + 1, blackLocations[i][1] * 100 + 1, 100, 100], 2)
#end of drawPieces

def checkOptions(pieces, locations, turn):
    moveList = []
    allMoveList = []
    
    for i in range(len(pieces)):
        location = locations[i]
        piece = pieces[i]
        
        match piece:
            case "pawn":
                moveList = checkPawnMoves(location, turn)
            case "rook":
               moveList = checkRookMoves(location, turn)
            case "knight":
                moveList = checkKnightMoves(location, turn)
            case "bishop":
                moveList = checkBishopMoves(location, turn)
            case "king":
                moveList = checkKingMoves(location, turn)
            case _:
                moveList = checkQueenMoves(location, turn)
        
        allMoveList.append(moveList)
        
    return allMoveList
#end of checkOptions

def checkPawnMoves(position, color):
    moveList = []
    
    if color == "white":
        if (position[0], position[1] + 1) not in whiteLocations and (position[0], position[1] + 1) not in blackLocations and position[1] < 7:
            moveList.append((position[0], position[1] + 1))
        if (position[0], position[1] + 2) not in whiteLocations and (position[0], position[1] + 2) not in blackLocations and \
            (position[0], position[1] + 1) not in whiteLocations and (position[0], position[1] + 1) not in blackLocations and position[1] == 1:
            moveList.append((position[0], position[1] + 2))
        if (position[0] + 1, position[1] + 1) in blackLocations:
            moveList.append((position[0] + 1, position[1] + 1))
        if (position[0] - 1, position[1] + 1) in blackLocations:
            moveList.append((position[0] - 1, position[1] + 1))
    else:
        if (position[0], position[1] - 1) not in whiteLocations and (position[0], position[1] - 1) not in blackLocations and position[1] > 0:
            moveList.append((position[0], position[1] - 1))
        if (position[0], position[1] - 2) not in whiteLocations and (position[0], position[1] - 2) not in blackLocations and \
            (position[0], position[1] - 1) not in whiteLocations and (position[0], position[1] - 1) not in blackLocations and position[1] == 6:
            moveList.append((position[0], position[1] - 2))
        if (position[0] + 1, position[1] - 1) in whiteLocations:
            moveList.append((position[0] + 1, position[1] - 1))
        if (position[0] - 1, position[1] - 1) in whiteLocations:
            moveList.append((position[0] - 1, position[1] - 1))
            
    return moveList
#end of checkPawnMoves

def checkRookMoves(position, color):
    moveList = []
    
    if color == "white":
        enemyList = blackLocations
        friendList = whiteLocations
    else:
        enemyList = whiteLocations
        friendList = blackLocations
        
    for i in range (4):
        path = True
        chain = 1
        
        match i:
            case 0:
                x = 0
                y = 1
            case 1:
                x = 0
                y = -1
            case 2:
                x = 1
                y = 0
            case _:
                x = -1
                y = 0
            
        while path:
            
            if (position[0] + (chain * x), position[1] + (chain * y)) not in friendList and \
                0 <= position[0] + (chain * x) <= 7 and 0 <= position[1] + (chain * y) <= 7:
                moveList.append((position[0] + (chain * x), position[1] + (chain * y)))
                
                if (position[0] + (chain * x), position[1] + (chain * y)) in enemyList:
                    path = False
                    
                chain += 1
            else:
                path = False
            
    return moveList
#end of checkRookMoves

def checkKnightMoves(position, color):
    moveList = []
    
    if color == "white":
        friendList = whiteLocations
    else:
        friendList = blackLocations
        
    targets = [(1, 2), (1, -2), (2, 1), (2, -1), (-1, 2), (-1, -2), (-2, 1), (-2, -1)]
    
    for i in range (8):
        target = (position[0] + targets[i][0], position[1] + targets[i][1])
        
        if target not in friendList and 0 <= target[0] <= 7 and 0 <= target[1] <= 7:
            moveList.append(target)
            
    return moveList
#end of checkKnightMoves

def checkBishopMoves(position, color):
    moveList = []
    
    if color == "white":
        enemyList = blackLocations
        friendList = whiteLocations
    else:
        enemyList = whiteLocations
        friendList = blackLocations
        
    for i in range (4):
        path = True
        chain = 1
        
        match i:
            case 0:
                x = 1
                y = -1
            case 1:
                x = -1
                y = -1
            case 2:
                x = 1
                y = 1
            case _:
                x = -1
                y = 1
            
        while path:
            
            if (position[0] + (chain * x), position[1] + (chain * y)) not in friendList and \
                0 <= position[0] + (chain * x) <= 7 and 0 <= position[1] + (chain * y) <= 7:
                moveList.append((position[0] + (chain * x), position[1] + (chain * y)))
                
                if (position[0] + (chain * x), position[1] + (chain * y)) in enemyList:
                    path = False
                    
                chain += 1
            else:
                path = False
    
    return moveList
#end of checkBishopMoves

def checkKingMoves(position, color):
    moveList = []
    
    if color == "white":
        friendList = whiteLocations
    else:
        friendList = blackLocations
        
    targets = [(1, 0), (1, 1), (1, -1), (-1, 0), (-1, 1), (-1, -1), (0, 1), (0, -1)]
    
    for i in range (8):
        target = (position[0] + targets[i][0], position[1] + targets[i][1])
        
        if target not in friendList and 0 <= target[0] <= 7 and 0 <= target[1] <= 7:
            moveList.append(target)
    
    return moveList
#end of checkKingMoves

def checkQueenMoves(position, color):
    moveList = checkBishopMoves(position, color)
    secondList = checkRookMoves(position, color)
    
    for i in range (len(secondList)):
        moveList.append(secondList[i])
    
    return moveList
#end of checkQueenMoves

def checkValidMoves():
    
    if turnStep < 2:
        optionsList = whiteOptions
    else:
        optionsList = blackOptions
    
    validOptions = optionsList[selection]
    
    return validOptions
#end of checkValidMoves

def drawValid(moves):
    
    if turnStep < 2:
        color = "red"
    else:
        color = "blue"
    
    for i in range (len(moves)):
        pygame.draw.circle(gameScreen, color, (moves[i][0] * 100 + 50, moves[i][1] * 100 + 50), 5)
#end of drawValid

def drawCaptured():
    
    for i in range (len(capturedPiecesWhite)):
        capturedPiece = capturedPiecesWhite[i]
        index = pieceList.index(capturedPiece)
        gameScreen.blit(blackImagesSmall[index], (825, 5 + 50 * i))
        
    for i in range (len(capturedPiecesBlack)):
        capturedPiece = capturedPiecesBlack[i]
        index = pieceList.index(capturedPiece)
        gameScreen.blit(whiteImagesSmall[index], (925, 5 + 50 * i))
#end of drawCaptured

def drawCheck():
    
    if "king" in whitePieces:
        kingIndex = whitePieces.index("king")
        kingLocation = whiteLocations[kingIndex]
        
        for i in range (len(blackOptions)):
            if kingLocation in blackOptions[i]:
                if counter < 15:
                    pygame.draw.rect(gameScreen, "dark red", [whiteLocations[kingIndex][0] * 100 + 1, whiteLocations[kingIndex][1] * 100 + 1, 100, 100], 5)

    if "king" in blackPieces:
        kingIndex = blackPieces.index("king")
        kingLocation = blackLocations[kingIndex]
            
        for i in range (len(whiteOptions)):
            if kingLocation in whiteOptions[i]:
                if counter < 15:
                    pygame.draw.rect(gameScreen, "dark blue", [blackLocations[kingIndex][0] * 100 + 1, blackLocations[kingIndex][1] * 100 + 1, 100, 100], 5)
#end of drawCheck

def drawGameOver():
    pygame.draw.rect(gameScreen, "black", [200, 200, 400, 70])
    gameScreen.blit(font.render(f'{winner} won the game!', True, "white"), (210, 210))
    gameScreen.blit(font.render("Press enter to replay!", True, "white"), (210, 240))
#end of drawGameOver

blackOptions = checkOptions(blackPieces, blackLocations, "black")
whiteOptions = checkOptions(whitePieces, whiteLocations, "white")
run = True

while run:
    timer.tick(fps)
    
    if counter < 30:
        counter += 1
    else:
        counter = 0
        
    gameScreen.fill("dark gray")
    drawBoard()
    drawPieces()
    drawCaptured()
    drawCheck()
    
    if selection != 100:
        validMoves = checkValidMoves()
        drawValid(validMoves)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not gameOver:
            xCord = event.pos[0] // 100
            yCord = event.pos[1] // 100
            clickCords = (xCord, yCord)
            if turnStep <= 1:
                if clickCords == (8, 8) or clickCords == (9, 8):
                    winner = "black"
                if clickCords in whiteLocations:
                    selection = whiteLocations.index(clickCords)
                    if turnStep == 0:
                        turnStep = 1
                if clickCords in validMoves and selection != 100:
                    whiteLocations[selection] = clickCords
                    if clickCords in blackLocations:
                        blackPiece = blackLocations.index(clickCords)
                        capturedPiecesWhite.append(blackPieces[blackPiece])
                        if blackPieces[blackPiece] == "king":
                            winner = "white"
                        blackPieces.pop(blackPiece)
                        blackLocations.pop(blackPiece)
                    blackOptions = checkOptions(blackPieces, blackLocations, "black")
                    whiteOptions = checkOptions(whitePieces, whiteLocations, "white")
                    turnStep = 2
                    selection = 100
                    validMoves = []
                    
            if turnStep > 1:
                if clickCords == (8, 8) or clickCords == (9, 8):
                    winner = "white"
                if clickCords in blackLocations:
                    selection = blackLocations.index(clickCords)
                    if turnStep == 2:
                        turnStep = 3
                if clickCords in validMoves and selection != 100:
                    blackLocations[selection] = clickCords
                    if clickCords in whiteLocations:
                        whitePiece = whiteLocations.index(clickCords)
                        capturedPiecesBlack.append(whitePieces[whitePiece])
                        if whitePieces[whitePiece] == "king":
                            winner = "black"
                        whitePieces.pop(whitePiece)
                        whiteLocations.pop(whitePiece)
                    blackOptions = checkOptions(blackPieces, blackLocations, "black")
                    whiteOptions = checkOptions(whitePieces, whiteLocations, "white")
                    turnStep = 0
                    selection = 100
                    validMoves = []
                    
        if event.type == pygame.KEYDOWN and gameOver:
            if event.key == pygame.K_RETURN:
                gameOver = False
                winner = ""
                whitePieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]
                whiteLocations = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
                blackPieces = ["rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn", "pawn"]
                blackLocations = [(0, 7), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (7, 6)]
                capturedPiecesWhite = []
                capturedPiecesBlack = []
                turnStep = 0
                selection = 100
                validMoves = []
                blackOptions = checkOptions(blackPieces, blackLocations, "black")
                whiteOptions = checkOptions(whitePieces, whiteLocations, "white")
                    
    if winner != "":
        gameOver = True
        drawGameOver()
            
    pygame.display.flip()
pygame.quit()